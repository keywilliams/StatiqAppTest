﻿namespace GeneratePagoFromBlazor.Models
{
    public class PrivacyViewModel
    {
        public string Name { get; set; }

        public DateTime Data { get; set; }
    }
}
